import os
import ray
from pprint import pprint

ray.init(code_search_path=["/tmp"])

@ray.remote
def hello_world():
    list_dir = os.listdir()
    current_dir = os.getcwd()

    results = "Working dir: {}\nList dir: {}\nCurrent dir: {}".format(
        working_dir, list_dir, current_dir
    )
    return results


result = ray.get(hello_world.remote())

pprint(dict(os.environ))
print(result)
