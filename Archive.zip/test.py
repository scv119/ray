import os
import ray
from pprint import pprint

ray.init(job_config=ray.job_config.JobConfig(code_search_path=["/tmp"]))

@ray.remote
def hello_world():
    list_dir = os.listdir()
    current_dir = os.getcwd()

    results = "List dir: {}\nCurrent dir: {}\nLoad from local:{}".format(
        list_dir, current_dir, ray._private.worker.global_worker.load_code_from_local
    )
    return results


result = ray.get(hello_world.remote())

pprint(dict(os.environ))
print(result)
